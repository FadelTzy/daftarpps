<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
        <a href="<?php echo e(url('admin')); ?>">SVA</a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
        <a href="<?php echo e(url('admin')); ?>">SVA</a>
    </div>
    <ul class="sidebar-menu">
        <li class="menu-header">Menu</li>

        <?php if(Auth::user()->role == 1 || Auth::user()->role == 3): ?>
            <li class="nav-item <?php echo e(Request::is('admin') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin')); ?>" class="nav-link "><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            
            <li class="nav-item <?php echo e(Request::segment(2) == 'pv-datamahasiswa' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/pv-datamahasiswa')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Data Mahasiswa</span></a>
            </li>
            <li class="menu-header">Manajemen Data Baru</li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'pv-pembayaran' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/pv-pembayaran')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Pembayaran</span></a>
            </li>
            <li
                class="nav-item <?php echo e(Request::segment(2) == 'pv-pembayaran/' . $semesaktif->kode_semester ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/pv-pembayaran')); ?>/<?php echo e($semesaktif->kode_semester); ?>" class="nav-link"><i
                        class="fas fa-columns"></i>
                    <span>Pembayaran <?php echo e($semesaktif->kode_semester); ?></span></a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'import-data' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/import-data')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Import Pembayaran Mahasiswa</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'status-data' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/status-data')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Status Pembayaran Mahasiswa</span></a>
            </li>
            <li class="menu-header">Manajemen Data Lama</li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'data-mahasiswa' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/data-mahasiswa')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Data Mahasiswa</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'data-va' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/data-va')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Data VA</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'pembayaran' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/pembayaran')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Pembayaran</span></a>
            </li>

            
            <li class="menu-header">Master Data</li>


            
            <li class="nav-item <?php echo e(Request::segment(2) == 'pvsemester' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/pvsemester')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Periode Semester</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'data-gelombang' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/data-gelombang')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Data Gelombang</span></a>
            </li>
            



            <?php if(Auth::user()->role == 1): ?>
                <li class="menu-header">Manajemen Admin</li>

                <li class="<?php echo e(Request::segment(2) == 'data-pengaturan' ? 'active' : ''); ?>"><a class="nav-link"
                        href="<?php echo e(route('pengaturan.index')); ?>"><i class="fas fa-pencil-ruler"></i>
                        <span>Pengaturan</span></a></li>
                <li class="<?php echo e(Request::segment(1) == 'profil' ? 'active' : ''); ?>"><a class="nav-link"
                        href="<?php echo e(url('profil')); ?>"><i class="fas fa-pencil-ruler"></i>
                        <span>Profil Admin</span></a></li>
            <?php else: ?>
            <?php endif; ?>
        <?php else: ?>
        <?php endif; ?>


    </ul>

    <div class=" mb-4 p-3 hide-sidebar-mini">
        <a href="#" id="" onclick="logsout()" class="btn btn-primary btn-lg btn-block btn-icon-split">
            <i class="fas fa-rocket"></i> Keluar
        </a>
        <form method="POST" id="flog" class="" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
        </form>
    </div>
</aside>
<script>
    function logsout() {
        var x = document.getElementById('flog');
        x.submit();
    }
</script>
<?php /**PATH C:\laragon\www\va\resources\views/components/asidebar.blade.php ENDPATH**/ ?>