<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
        <a href="<?php echo e(url('admin')); ?>">e-BK</a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
        <a href="<?php echo e(url('admin')); ?>">e-BK</a>
    </div>
    <ul class="sidebar-menu">
        <li class="menu-header">Menu</li>

        <?php if(Auth::user()->role == 1 || Auth::user()->role == 3): ?>
            <li class="nav-item <?php echo e(Request::is('admin') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('admin')); ?>" class="nav-link "><i class="fas fa-fire"></i><span>Dashboard</span></a>
            </li>
            <li class="menu-header">Manajemen Data</li>
            <?php if(Auth::user()->role == 1): ?>
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link has-dropdown" data-toggle="dropdown"><i
                            class="fas fa-columns"></i>
                        <span>Data User</span></a>
                    <ul class="dropdown-menu">
                        <li><a class="nav-link" href="<?php echo e(route('dosen.index')); ?>">Data Siswa </a></li>
                        <li><a class="nav-link" href="<?php echo e(route('guru.index')); ?>">Data Guru </a></li>

                        <li><a class="nav-link" href="<?php echo e(route('admin.index')); ?>">Data Admin</a></li>
                    </ul>
                </li>
            <?php endif; ?>
            <li class="nav-item <?php echo e(Request::segment(2) == 'konsultasi-siswa' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/konsultasi-siswa')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Konsultasi Siswa</span></a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'pelanggaran-siswa' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/pelanggaran-siswa')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Pelanggaran Siswa</span></a>
            </li>

            <li class="nav-item <?php echo e(Request::segment(2) == 'qr-code' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/qr-code')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>QR Code</span></a>

            </li>
            <li class="menu-header">Master Data</li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'data-pelanggaran' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/data-pelanggaran')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Jenis Pelanggaran</span></a>

            </li>

            <li class="nav-item <?php echo e(Request::segment(2) == 'data-bataspelanggaran' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/data-bataspelanggaran')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Batas Pelanggaran</span></a>

            </li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'data-topik' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('admin/data-topik')); ?>" class="nav-link"><i class="fas fa-columns"></i>
                    <span>Topik Konsultasi</span></a>

            </li>

            <?php if(Auth::user()->role == 1): ?>
                <li class="menu-header">Manajemen Admin</li>

                <li class="<?php echo e(Request::segment(2) == 'data-pengaturan' ? 'active' : ''); ?>"><a class="nav-link"
                        href="<?php echo e(route('pengaturan.index')); ?>"><i class="fas fa-pencil-ruler"></i>
                        <span>Pengaturan</span></a></li>
                <li class="<?php echo e(Request::segment(1) == 'profil' ? 'active' : ''); ?>"><a class="nav-link"
                        href="<?php echo e(url('profil')); ?>"><i class="fas fa-pencil-ruler"></i>
                        <span>Profil Admin</span></a></li>
            <?php else: ?>
                <li class="menu-header">Manajemen Guru</li>

                <li class="<?php echo e(Request::segment(1) == 'profil' ? 'active' : ''); ?>"><a class="nav-link"
                        href="<?php echo e(url('profil')); ?>"><i class="fas fa-pencil-ruler"></i>
                        <span>Profil </span></a></li>
            <?php endif; ?>
        <?php else: ?>
            <li class="nav-item <?php echo e(Request::segment(2) == 'qr-code' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('siswa/qr-code') . '/' . Auth::user()->id); ?>" class="nav-link"><i
                        class="fas fa-columns"></i>
                    <span>Dashboard</span></a>

            </li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'konsultasi-siswa' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('siswa/konsultasi-siswa') . '/' . Auth::user()->id); ?>" class="nav-link"><i
                        class="fas fa-columns"></i>
                    <span>Konsultasi </span></a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'data-pelanggaran' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('siswa/data-pelanggaran') . '/' . Auth::user()->id); ?>" class="nav-link"><i
                        class="fas fa-columns"></i>
                    <span>Pelanggaran </span></a>
            </li>
            <li class="nav-item <?php echo e(Request::segment(2) == 'data-sanksi' ? 'active' : ''); ?>">
                <a href="<?php echo e(url('siswa/data-sanksi') . '/' . Auth::user()->id); ?>" class="nav-link"><i
                        class="fas fa-columns"></i>
                    <span>Sanksi </span></a>
            </li>

            <li class="<?php echo e(Request::segment(1) == 'profil' ? 'active' : ''); ?>"><a class="nav-link"
                    href="<?php echo e(url('profil')); ?>"><i class="fas fa-pencil-ruler"></i>
                    <span>Profil </span></a></li>
        <?php endif; ?>


    </ul>

    <div class=" mb-4 p-3 hide-sidebar-mini">
        <a href="#" id="" onclick="logsout()" class="btn btn-primary btn-lg btn-block btn-icon-split">
            <i class="fas fa-rocket"></i> Keluar
        </a>
        <form method="POST" id="flog" class="" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
        </form>
    </div>
</aside>
<script>
    function logsout() {
        var x = document.getElementById('flog');
        x.submit();
    }
</script>
<?php /**PATH C:\xampp\htdocs\ebk\resources\views/components/asidebar.blade.php ENDPATH**/ ?>