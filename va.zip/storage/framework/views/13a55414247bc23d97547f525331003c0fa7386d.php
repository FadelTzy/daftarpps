

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('stisla/assets/modules/izitoast/css/iziToast.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Profil
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h1> Profil
            </h1>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-12 col-sm-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Informasi Admin</h4>
                        </div>
                        <div class="card-body">

                            <form id="datakontak" action="<?php echo e(url('profil')); ?>" method="POST" enctype="multipart/form-data">
                                <div class="tab-content" id="myTabContent2">

                                    <div class="tab-pane fade show active" id="home3" role="tabpanel"
                                        aria-labelledby="home-tab3">
                                        <div class="card">

                                            <div class="card-body">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Nama</label>
                                                            <input value="<?php echo e(Auth::user()->name); ?>" type="text"
                                                                name="nama" class="form-control">
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>No</label>
                                                            <input value="<?php echo e(Auth::user()->no); ?>" type="text"
                                                                name="no" class="form-control">
                                                        </div>
                                                    </div>


                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Email</label>
                                                            <input value="<?php echo e(Auth::user()->email); ?>" type="text"
                                                                name="email" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Username</label>
                                                            <input value="<?php echo e(Auth::user()->username); ?>" type="text"
                                                                name="username" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Set Password Baru</label>
                                                            <input type="text" name="pass" class="form-control">
                                                        </div>
                                                    </div>
                                                    <?php if(Auth::user()->role == 2): ?>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>Foto </label>
                                                                <input type="file" name="foto" class="form-control">
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>




                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="form-group row mb-4">
                                    <label class="col-form-label text-md-right "></label>
                                    <div class="col-sm-12 col-md-7">
                                        <button type="submit" class="btn btn-warning">Simpan</button>


                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <!-- Page Specific JS File -->
    <script src="<?php echo e(asset('stisla/assets/modules/izitoast/js/iziToast.min.js')); ?>"></script>
    <?php if(session('message')): ?>
        <script>
            iziToast.success({
                title: 'Succes!',
                message: 'Data tersimpan',
                position: 'topRight'
            });
        </script>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <script>
            var data = '<?php echo session('data'); ?>';
            console.log(data)
            var parse = JSON.parse(data);
            iziToast.error({
                title: 'Error',
                message: data,
                position: 'topRight'
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('ab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebk\resources\views/admin/profil.blade.php ENDPATH**/ ?>