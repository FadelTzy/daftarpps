<!doctype html>
<html lang="en" class="h-100">


<!-- Mirrored from maxartkiller.com/website/finwallapp2/HTML/signin.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 25 Sep 2022 09:02:32 GMT -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="generator" content="">
    <title>Chemical Industry Tools</title>

    <!-- manifest meta -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="manifest" href="manifest.json" />

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="<?php echo e(asset('asset/img/favicon180.png')); ?>" sizes="180x180">
    <link rel="icon" href="<?php echo e(asset('asset/img/favicon32.png')); ?>" sizes="32x32" type="image/png">
    <link rel="icon" href="<?php echo e(asset('asset/img/favicon16.png')); ?>" sizes="16x16" type="image/png">

    <!-- Google fonts-->

    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&amp;display=swap"
        rel="stylesheet">

    <!-- bootstrap icons -->
    <link rel="stylesheet"
        href="<?php echo e(asset('asset/cdn.jsdelivr.net/npm/bootstrap-icons%401.5.0/font/bootstrap-icons.css')); ?>">

    <!-- style css for this template -->
    <link href="<?php echo e(asset('asset/css/style.css')); ?>" rel="stylesheet" id="style">
</head>

<body class="body-scroll d-flex flex-column h-100" data-page="signin">

    <!-- loader section -->
    <div class="container-fluid loader-wrap">
        <div class="row h-100">
            <div class="col-10 col-md-6 col-lg-5 col-xl-3 mx-auto text-center align-self-center">
                
                <img width="30%" src="<?php echo e(asset('file/logo/') .'/' . $set->logo); ?>" alt="">
                <p class="mt-4"><span class="text-secondary"><?php echo e($set->nama); ?></span><br><strong>Please
                        wait...</strong></p>
            </div>
        </div>
    </div>
    <!-- loader section ends -->

    <!-- Begin page content -->
    <main class="container-fluid h-100 ">
        <div class="row h-100">
            <div class="col-11 col-sm-11 mx-auto">
                <!-- header -->
                <div class="row">
                    <header class="header">
                        <div class="row">
                            <div class="col">
                                <div class="logo-small">
                                    
                                    <img src="<?php echo e(asset('file/logo/') .'/' . $set->logo); ?>" alt="">
                                    <h5><span class="text-secondary fw-light"><?php echo e($set->nama); ?></span><br /></h5>
                                </div>
                            </div>
                            <div class="col-auto align-self-center">
                            </div>
                        </div>
                    </header>
                </div>
                <!-- header ends -->
            </div>
            

            <!-- Validation Errors -->
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="col-11 col-sm-11 col-md-6 col-lg-5 col-xl-3 mx-auto align-self-center py-4">
                    <h1 class="mb-4"><span class="text-secondary fw-light">Login</span><br />Ke Akun</h1>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                    <div class="form-group form-floating mb-3 is-valid">
                        <input type="text" class="form-control"  id="username" name="username"
                            placeholder="Username">
                        <label class="form-control-label" for="username">Username</label>
                    </div>
                    
                    <div class="form-group form-floating is-valid mb-3">
                        <input type="password" class="form-control " name="password" id="password"
                            placeholder="Password">
                        <label class="form-control-label" for="password">Password</label>
                        <button type="button" class="text-danger tooltip-btn" data-bs-toggle="tooltip"
                            data-bs-placement="left" title="Enter valid Password" id="passworderror">
                        </button>
                    </div>
                    <p class="mb-3 text-end">
                      
                    </p>
                </div>
                <div class="col-11 col-sm-11 mt-auto mx-auto py-4">
                    <div class="row ">
                        <div class="col-12 d-grid">
                            <button type="submit" class="btn btn-default btn-lg shadow-sm">Login</button>
                        </div>
                    </div>
                </div>
            </form>

        </div>
    </main>




    <!-- Required jquery and libraries -->
    <script src="<?php echo e(asset('asset/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/vendor/bootstrap-5/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- page level custom script -->
    <script src="<?php echo e(asset('asset/js/app.js')); ?>"></script>

    <!-- Customized jquery file  -->
    <script src="<?php echo e(asset('asset/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/js/color-scheme.js')); ?>"></script>

    <!-- PWA app service registration and works -->
    <script src="<?php echo e(asset('asset/js/pwa-services.js')); ?>"></script>

</body>


<!-- Mirrored from maxartkiller.com/website/finwallapp2/HTML/signin.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 25 Sep 2022 09:02:33 GMT -->

</html>
<?php /**PATH /home/u5280864/public_html/bk.antangdev.site/laravel/resources/views/user/login.blade.php ENDPATH**/ ?>