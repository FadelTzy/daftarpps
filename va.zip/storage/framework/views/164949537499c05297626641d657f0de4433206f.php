<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2022 <div class="bullet"></div> Design By INKA<a href=""></a>
    </div>
    <div class="footer-right">
        2.3.0
    </div>
</footer>
<?php /**PATH /home/u5280864/public_html/bk.antangdev.site/laravel/resources/views/components/afooter.blade.php ENDPATH**/ ?>